﻿Imports System.Reflection

Public Class Form1
    Private Property studentData As CourseManagement.Student
    Property user_ As String
    Property UserName As String
        Get
            Return user_
        End Get
        Set(value As String)
            'do some stuff that loads the users data 
            Dim rawClass_list = CourseManagement.Student.GetClass_table(
                "Select *
            from student
            where
            FirstName like '" & value & "'")
            studentData = rawClass_list(0)
            Dim iQuery = (From ii In rawClass_list
                          Select ii.FirstName, ii.LastName, ii.AccountBalance,
                              ii.Credits, ii.CumulativeGPA, ii.CurrentHours,
                              ii.Field_of_study, ii.Major, ii.Minor,
                              ii.SemesterGPA)
            Dim dt = CourseManagement.DBIO.ConvertToDataTable(iQuery)
                DataGridView1.DataSource = dt

            Dim Couses = CourseManagement.Courses.GetClass_table("select * from courses ")
            Dim iQuery2 = (From ii In CourseManagement.StudentCourses.GetClass_table(
                    "Select *
            from StudentCourses
            where
            StudentID = " & studentData.ID & ""
                          )
                           Join ee In Couses On ii.CourseID Equals ee.ID
                           Select ii.ID, ee.CourseName, ii.CourseID, ii.GPA, ii.Startdate, ii.Enddate, ii.Credits)



            dt = CourseManagement.DBIO.ConvertToDataTable(iQuery2)
            DataGridView2.DataSource = dt
            '          Load_couse_data(DataGridView2)
            user_ = value
        End Set
    End Property
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '   create_data()
        '       Close()
        Dim ll = New LoginForm
        ll.TextBox1.Text = "Mattheu"
        ll.TextBox2.Text = "Password"

        ll.ShowDialog()


    End Sub
    Sub create_data()
        For i = 0 To 5
            createStudentcourse(3, i)
        Next
        createStudent()
        createcourse(3,
                         1,
                         "Calculus",
                         "MWF",
                         "BASIC",
                         "DR. Elm",
                         "A109",
                         Now.Date.AddHours(7),
                         Now.Date.AddHours(7).AddHours(1)
                         )
        createcourse(3,
                         2,
                         "American History",
                         "MWF",
                         "BASIC",
                         "Mrs. Potatoe",
                         "A115",
                         Now.Date.AddHours(8),
                         Now.Date.AddHours(8).AddHours(1).AddMinutes(15)
                         )
        createcourse(3,
                         3,
                         "English 1301",
                         "MWF",
                         "BASIC",
                         "Mr. Holders",
                         "E704",
                         Now.Date.AddHours(10),
                         Now.Date.AddHours(10).AddHours(1)
                         )
        createcourse(3,
                         4,
                         "Chemistry",
                         "TUTH",
                         "BASIC",
                         "Mr. Sanchez",
                         "C459",
                         Now.Date.AddHours(7),
                         Now.Date.AddHours(7).AddHours(1)
                         )
        createcourse(3,
                         5,
                         "Programming I",
                         "TUTH",
                         "SCIENCE",
                         "Mr. Wooloo",
                         "E759",
                         Now.Date.AddHours(12),
                         Now.Date.AddHours(12).AddHours(1)
                         )

    End Sub
    Sub createStudent()
        Dim stud = New CourseManagement.Student
        With stud
            .AccountBalance = 0
            .CourseDropCount = 0
            .Credits = 48
            .CumulativeGPA = 3.9
            .CurrentHours = 18
            .DOB = CDate("09/26/1988")
            .EnrollmentDate = Now.AddYears(-5)
            .Field_of_study = "Science"
            .FirstName = "Mattheu"
            .LastName = "Norwood"
            .Major = "Computer Science"
            .Minor = "Business"
            Dim ssd = New Simple3Des("Mykey")
            Dim i1 = ssd.EncryptData("Password")
            .PassWordHash = i1
            .SemesterGPA = 4
            .Sex = "M"


        End With
        CourseManagement.Student.InsertRecord(stud)
    End Sub

    Sub createStudentcourse(cred As Integer,
                            cID As Integer
                            )
        Dim stud = New CourseManagement.StudentCourses
        With stud

            .Credits = cred
            .Active = "Y"
            .CourseID = cID
            .Enddate = Now.AddMonths(4)
            .GPA = 4
            .Startdate = Now
            .StudentID = 1


        End With
        CourseManagement.StudentCourses.InsertRecord(stud)
    End Sub
    Sub createcourse(cred As Integer,
                            cID As Integer,
                     cnames As String,
                     dow As String,
                     DC As String,
                     prof As String,
                     rn As String,
                     sStart As Date,
                     send As Date)
        Dim stud = New CourseManagement.Courses
        With stud
            .Building = "A10" & cID
            .CourseName = cnames
            .DaysOfWeek = dow
            .DegreeCategory = DC
            .Credits = cred


            .Enddate = Now.AddMonths(4)

            .Startdate = Now
            .Professor = prof
            .RoomNumber = rn
            .SessionEnd = send
            .SessionStart = sStart



        End With
        CourseManagement.Courses.InsertRecord(stud)
    End Sub


    Private Sub DataGridView2_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView2.SelectionChanged
        Load_couse_data(sender)
    End Sub
    Sub Load_couse_data(sender As Object)
        Try
            Dim DGV As DataGridView = sender
            If DGV.SelectedRows.Cast(Of DataGridViewRow).Count = 0 Then
                DGV.Rows.Cast(Of DataGridViewRow).ToList(0).Selected = True
                Exit Sub
            End If

            Dim row = DGV.SelectedRows.Cast(Of DataGridViewRow).ToList(0)
            Dim ID_Col = DGV.Columns.Cast(Of DataGridViewColumn).ToList.Find(Function(x) x.Name = "CourseID")
            Dim ID = row.Cells.Cast(Of DataGridViewCell).ToList.Find(Function(x) x.ColumnIndex = ID_Col.Index).Value
            Dim iQuery2 = (From ii In CourseManagement.Courses.GetClass_table(
                    "
                               Select *
            from Courses
            where
            ID = " & ID & ""
                          )
                           Select ii.CourseName, ii.DegreeCategory, ii.Professor, ii.Building, ii.RoomNumber, ii.DaysOfWeek, ii.SessionStart, ii.SessionEnd, ii.Credits)
            Dim dt = CourseManagement.DBIO.ConvertToDataTable(iQuery2)
            DataGridView6.DataSource = dt


            Dim iQuery3 = (From ii In CourseManagement.StudentCourseGrades.GetClass_table(
        "
                               Select *
            from StudentCourseGrades
            where
            CourseID = " & ID & ""
              )
                           Select ii.AssignmentName, ii.Grade, ii.GradeWeight, ii.Assigneddate, ii.Duedate)

            dt = CourseManagement.DBIO.ConvertToDataTable(iQuery3)
            DataGridView3.DataSource = dt



        Catch ex As Exception

        End Try
    End Sub

End Class
