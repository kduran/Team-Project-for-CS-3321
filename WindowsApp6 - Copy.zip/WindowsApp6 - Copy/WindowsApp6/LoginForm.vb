﻿Public Class LoginForm
    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Function Login(user_ As String, password_ As String) As Boolean
        Try
            Dim ssd = New Simple3Des("Mykey")
            Dim i1 = ssd.EncryptData(password_)
            Dim userHash = CourseManagement.Student.GetClass_table(
                "Select PassWordHash 
            from student
            where
            FirstName like '" & user_ & "'")(0).PassWordHash
            If i1 = userHash Then
                '   MsgBox("Autorized!")
                Form1.UserName = user_
                Close()
            Else
                MsgBox("Access denied! {Invalid Password}")
            End If
        Catch ex As Exception
            MsgBox("Access denied! {Invalid UserName}
")
        End Try
    End Function
    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Login(TextBox1.Text, TextBox2.Text)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Login(TextBox1.Text, TextBox2.Text)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Login(TextBox1.Text, TextBox2.Text)
    End Sub
End Class