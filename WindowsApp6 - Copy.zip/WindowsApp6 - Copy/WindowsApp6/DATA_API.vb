﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Reflection



''' <summary>
''' This is a .NET reflection of the CourseManagement catelog that allows for 
''' automated SQL transactions and SQL table to vb class oganization
''' </summary>
Namespace CourseManagement

    ''' <summary>
    ''' Database Input Output 
    ''' This class is the centralized IO controller for all sql tables reflected in this catelog 
    ''' the connection strings and transaction statments are already prebuilt to standardize 
    ''' IO transactions with the SQL database
    ''' </summary>
    Public Class DBIO


        Public Shared Function ConvertToDataTable(Of TSource)(source As IEnumerable(Of TSource)) As DataTable
            Dim props = GetType(TSource).GetProperties()

            Dim dt = New DataTable()
            dt.Columns.AddRange(props.[Select](Function(p) New DataColumn(p.Name, p.PropertyType)).ToArray())

            source.ToList().ForEach(Function(i) dt.Rows.Add(props.[Select](Function(p) p.GetValue(i, Nothing)).ToArray()))

            Return dt
        End Function
        ''' <summary>
        ''' set this true if you want to write the IO queries to H:\Installapps\storedqueries\%USERNAME%
        ''' </summary>
        Public Shared WriteOutput As Boolean = False
        ''' <summary>
        ''' stores your last query datatable here 
        ''' </summary>
        Public Shared LastDatatable As DataTable
        ''' <summary>
        ''' This is a debugging tool allowing you to review the queries and their output here 
        ''' the grid is acumaltive to the session so in cases of high frequency tranactions in long session you may need to garbage collect
        ''' </summary>
        Public Class StoredQuery
            ReadOnly Property UserName As String
                Get
                    Return Environment.UserName
                End Get
            End Property
            ReadOnly Property MachineName As String
                Get
                    Return Environment.MachineName
                End Get
            End Property
            ReadOnly Property ProgramDirectoryPath As String
                Get
                    Return My.Application.Info.DirectoryPath
                End Get
            End Property
            ReadOnly Property ProgramName As String
                Get
                    Return My.Application.Info.AssemblyName
                End Get
            End Property
            Property qString As String
            Property qTime As DateTime
            Property qType As String
            Property qErrors As String
            Public Shared StoredQueries As New List(Of StoredQuery)()
            Sub New()
                StoredQueries.Add(Me)
            End Sub
        End Class
        ''' <summary>
        ''' This is a generic query function that returns a datatable that the namespace data classes use to fill records with 
        ''' If you are having issues turn on Writeoutput 
        ''' </summary>
        ''' <param name="Querry_string"></param>
        ''' <returns></returns>
        Public Shared Function DirectQuery(Querry_string As String) As DataTable
            Dim sQ = New StoredQuery
            Dim dt As New DataTable
            Try
                With sQ
                    .qString = Querry_string
                    .qTime = Now
                    .qType = "query"
                End With
                Dim conn = LoadConnection()
                conn.Open()
                Dim cmd = (Querry_string)

                Dim sqlADP As New SqlDataAdapter(cmd, conn)
                Using sqlADP
                    sqlADP.Fill(dt)
                End Using
                dt.AcceptChanges()
                conn.Close()

            Catch ex As Exception
                sQ.qErrors = ex.Message
            End Try
            If WriteOutput = True Then
                Try
                    Dim d = Now.Date
                    Dim dir_ = "H:\Install Apps\StoredQueries\" & sQ.UserName & "\" & sQ.ProgramName & "\"
                    If Directory.Exists(dir_) = False Then Directory.CreateDirectory(dir_)
                    Dim file_ = dir_ & d.Year & d.Month & d.Day & ".txt"
                    If IO.File.Exists(file_) Then
                        Using sw As StreamWriter = IO.File.AppendText(file_)
                            sw.WriteLine()
                            sw.WriteLine("Time = [" & sQ.qTime & "]")
                            sw.WriteLine("Query = " & sQ.qString)
                            sw.WriteLine("Errors= " & sQ.qErrors)
                            sw.WriteLine("Machine =  " & sQ.MachineName)
                            sw.WriteLine("Dir = " & sQ.ProgramDirectoryPath)
                            sw.WriteLine("Program = " & sQ.ProgramName)
                            sw.WriteLine()
                        End Using
                    Else
                        Using sw As StreamWriter = IO.File.CreateText(file_)
                            sw.WriteLine()
                            sw.WriteLine("Time = [" & sQ.qTime & "]")
                            sw.WriteLine("Query = " & sQ.qString)
                            sw.WriteLine("Errors= " & sQ.qErrors)
                            sw.WriteLine("Machine =  " & sQ.MachineName)
                            sw.WriteLine("Dir = " & sQ.ProgramDirectoryPath)
                            sw.WriteLine("Program = " & sQ.ProgramName)
                            sw.WriteLine()
                        End Using
                    End If
                Catch ex As Exception

                End Try
            End If
            LastDatatable = dt
            Return dt
        End Function
        ''' <summary>
        ''' This Merges 2 vb.net datatables into one the columns must match 
        ''' </summary>
        ''' <param name="dt1"></param>
        ''' <param name="dt2"></param>
        ''' <returns></returns>
        Public Shared Function MergeDataTables(dt1 As DataTable,
                                               dt2 As DataTable) As DataTable

            Dim newtable As New DataTable
            For c As Integer = 0 To dt1.Columns.Count - 1
                newtable.Columns.Add(dt1.Columns.Item(c).ColumnName, dt1.Columns.Item(c).DataType)
            Next
            For Each row As DataRow In dt1.Rows
                Dim newrow As DataRow = row
                newtable.ImportRow(row)
            Next
            For Each row As DataRow In dt2.Rows
                Dim newrow As DataRow = row
                newtable.ImportRow(row)
            Next
            Return newtable
        End Function
        Public Shared Function DirectQuery(Querry_string As String,
                                           connection_string As String) As DataTable
            Dim conn = LoadConnection(connection_string)
            conn.Open()
            Dim cmd = (Querry_string)
            Dim dt As New DataTable
            Dim sqlADP As New SqlDataAdapter(cmd, conn)
            Using sqlADP
                sqlADP.Fill(dt)
            End Using
            dt.AcceptChanges()
            conn.Close()
            Return dt
        End Function

        Public Shared Function LoadConnection() As SqlConnection

            Dim conn = New SqlConnection("Data Source=gateway\MSSQLSERVER01;Initial Catalog=CourseManagement;Integrated Security=True")
            Return conn
        End Function
        Public Shared Function LoadConnection(connection_string As String) As SqlConnection
            Dim conn = New SqlConnection(connection_string)
            Return conn
        End Function
        ''' <summary>
        ''' This runs a sql command with the storedquery audit class inside 
        ''' </summary>
        ''' <param name="commandString"></param>
        ''' <returns></returns>
        Public Shared Function DirectCommand(commandString As String) As String
            Dim sQ = New StoredQuery
            Try
                With sQ
                    .qString = commandString
                    .qTime = Now
                    .qType = "Command"
                End With
                Dim cnn As SqlConnection = LoadConnection()
                Dim cmd As New SqlCommand(commandString, cnn)
                cnn.Open()
                cmd.ExecuteNonQuery()
                cnn.Close()
            Catch ex As Exception
                sQ.qErrors = ex.Message
            End Try
            If WriteOutput = True Then
                Try
                    Dim d = Now.Date
                    Dim dir_ = "H:\Install Apps\StoredQueries\" & sQ.UserName & "\" & sQ.ProgramName & "\"
                    If Directory.Exists(dir_) = False Then Directory.CreateDirectory(dir_)
                    Dim file_ = dir_ & d.Year & d.Month & d.Day & ".txt"
                    If IO.File.Exists(file_) Then
                        Using sw As StreamWriter = IO.File.AppendText(file_)
                            sw.WriteLine()
                            sw.WriteLine("Time = [" & sQ.qTime & "]")
                            sw.WriteLine("Query = " & sQ.qString)
                            sw.WriteLine("Errors= " & sQ.qErrors)
                            sw.WriteLine("Machine =  " & sQ.MachineName)
                            sw.WriteLine("Dir = " & sQ.ProgramDirectoryPath)
                            sw.WriteLine("Program = " & sQ.ProgramName)
                            sw.WriteLine()
                        End Using
                    Else
                        Using sw As StreamWriter = IO.File.CreateText(file_)
                            sw.WriteLine()
                            sw.WriteLine("Time = [" & sQ.qTime & "]")
                            sw.WriteLine("Query = " & sQ.qString)
                            sw.WriteLine("Errors= " & sQ.qErrors)
                            sw.WriteLine("Machine =  " & sQ.MachineName)
                            sw.WriteLine("Dir = " & sQ.ProgramDirectoryPath)
                            sw.WriteLine("Program = " & sQ.ProgramName)
                            sw.WriteLine()
                        End Using
                    End If
                Catch ex As Exception

                End Try
            End If
            Return sQ.qErrors
        End Function
        Public Shared Function DirectCommand(commandString As String,
                                             connection_string As String) As String
            Try
                Dim cnn As SqlConnection = LoadConnection(connection_string)
                Dim cmd As New SqlCommand(commandString, cnn)
                cnn.Open()
                cmd.ExecuteNonQuery()
                cnn.Close()
            Catch ex As Exception
                Return ex.Message
            End Try

        End Function

        ''' <summary>
        ''' create a copy of a class instantly 
        ''' exp:Get_portable_class(New ServiceSchedule())
        ''' the code is now on your clipboard
        ''' </summary>
        ''' <param name="iObject"></param>
        ''' <returns></returns>
        Public Function Get_portable_class(iObject As Object) As String
            Dim name_ = (iObject.GetType.FullName.Replace("+", "."))
            Dim Output As String = Nothing
            Output = "Public Class " & iObject.GetType.Name & "_ " & vbNewLine
            Output += "     Private property Raw_IO as " & name_ & " " & vbNewLine
            For Each p As PropertyInfo In iObject.GetType.GetProperties.ToList.FindAll(Function(x) x.Name <> "ID")
                Output += "     Private property " & p.Name & " as " & p.PropertyType.ToString & " " & vbNewLine
                Output += "          Get" & vbNewLine
                Output += "              return  Raw_IO." & p.Name & vbNewLine
                Output += "          End Get" & vbNewLine
                Output += "          Set(value As " & p.PropertyType.ToString & ")" & vbNewLine
                Output += "              Raw_IO." & p.Name & " = value" & vbNewLine
                Output += "          End Set" & vbNewLine
                Output += "     End Property" & vbNewLine
            Next
            Output += "     Sub New(raw_ As " & name_ & ")" & vbNewLine
            Output += "          Raw_IO = raw_" & vbNewLine
            Output += "          iGrid.Add(Me)" & vbNewLine
            Output += "     End Sub" & vbNewLine
            Output += "     Public Shared iGrid As New List(Of " & iObject.GetType.Name & "_)()" & vbNewLine
            Output += "End Class" & vbNewLine
            My.Computer.Clipboard.SetText(Output)

            Return Output


        End Function
        ''' <summary>
        ''' creates a Generic list of objects from a datacolumn
        ''' </summary>
        ''' <param name="DT"></param>
        ''' <param name="ColumnName"></param>
        ''' <returns></returns>
        Public Shared Function Select_DT_column_tolist(DT As DataTable,
                                                   ColumnName As String) As List(Of Object)
            Return DT.Rows.Cast(Of DataRow).Select(Function(dr) dr(ColumnName)).ToList
        End Function
        ''' <summary>
        ''' create a datatable from a CSV file 
        ''' </summary>
        ''' <param name="filepath"></param>
        ''' <returns></returns>
        Public Shared Function CsvtoDT(filepath As String) As DataTable
            Dim dt As New DataTable
            Using MyReader As New Microsoft.VisualBasic.
                      FileIO.TextFieldParser(
                       filepath)
                MyReader.TextFieldType = FileIO.FieldType.Delimited
                MyReader.SetDelimiters(",")
                Dim currentRow As String()
                Dim headerrow As Boolean = True
                While Not MyReader.EndOfData

                    Try
                        currentRow = MyReader.ReadFields()
                        Dim row As DataRow = dt.NewRow
                        Dim currentField As String
                        Dim ridx = 0
                        For Each currentField In currentRow
                            Try
                                Select Case headerrow
                                    Case True
                                        Try
                                            Dim dc As New DataColumn(currentField)
                                            dt.Columns.Add(dc)
                                        Catch ex As Exception
                                            Console.WriteLine(ex.Message)
                                            Dim dc As New DataColumn("placeholder " & dt.Columns.Count)
                                            dt.Columns.Add(dc)
                                        End Try

                                    Case False
                                        Try
                                            row.Item(ridx) = currentField
                                            ridx = ridx + 1
                                        Catch ex As Exception
                                            Console.WriteLine(ex.Message)
                                            row.Item(ridx) = " "
                                            ridx = ridx + 1
                                        End Try

                                End Select
                            Catch ex As Exception

                            End Try
                        Next
                        Select Case headerrow
                            Case True
                            Case False
                                dt.Rows.Add(row)
                        End Select
                        headerrow = False
                    Catch ex As Microsoft.VisualBasic.
                        FileIO.MalformedLineException
                        MsgBox("Line " & ex.Message &
                "is not valid and will be skipped.")
                    End Try
                End While
            End Using
            dt.AcceptChanges()
            Return dt
        End Function
        ''' <summary>
        ''' convert a list of class records to a datatable 
        ''' 
        ''' </summary>
        ''' <typeparam name="T"></typeparam>
        ''' <param name="list"></param>
        ''' <returns></returns>
        Public Shared Function ConvertToDataTable(Of T)(ByVal list As IList(Of T)) As DataTable
            Try
                Dim table As New DataTable()
                Dim name As String = list.Item(0).GetType.Name
                table.TableName = name
                If Not list.Any Then
                    'don't know schema ....
                    Return table
                End If
                Dim fields() = list.First.GetType.GetProperties
                For Each field In fields
                    table.Columns.Add(field.Name, field.PropertyType)
                Next
                For Each item In list
                    Try
                        Dim row As DataRow = table.NewRow()
                        For Each field In fields
                            Dim p = item.GetType.GetProperty(field.Name)
                            row(field.Name) = p.GetValue(item, Nothing)
                        Next
                        table.Rows.Add(row)
                    Catch ex As Exception

                    End Try

                Next
                Return table
            Catch ex As Exception

            End Try

        End Function
        ''' <summary>
        ''' copies a class values to another class record 
        ''' the object type does not have to match but the proerties have to match name this is case sensative 
        ''' </summary>
        ''' <param name="CL_1"></param>
        ''' <param name="CL_2"></param>
        ''' <returns></returns>
        Public Shared Function SetClass_to_new_class(CL_1 As Object,
                                   CL_2 As Object
    ) As Object
            For Each p As PropertyInfo In CL_2.GetType.GetProperties.ToList

                Try
                    For Each pp As PropertyInfo In CL_1.GetType.GetProperties.ToList.FindAll(Function(x) x.Name = p.Name)
                        Try
                            pp.SetValue(CL_1, p.GetValue(CL_2))
                        Catch ex As Exception

                        End Try
                    Next
                Catch ex As Exception

                End Try
skipKEY:
            Next
            Return CL_1
        End Function


    End Class


    ''' <summary>
    ''' This is a reflection of [CourseManagement].[dbo].[Courses], it mirrors all the columns as properties and converts sql dbtypes to vb data types.
    ''' With this class you can insert, select and update records without having to write out the sql statments. 
    ''' </summary>
    Public Class Courses
        Enum CoursesColumns
            [ID] = 0
            [CourseName] = 1
            [DegreeCategory] = 2
            [Professor] = 3
            [Building] = 4
            [RoomNumber] = 5
            [DaysOfWeek] = 6
            [SessionStart] = 7
            [SessionEnd] = 8
            [Startdate] = 9
            [Enddate] = 10
            [Credits] = 11
        End Enum

#Region "VARS"
        Property [AllowUpdate] As Boolean
#Region "ID_"
        Private Property ID_ As Integer
        ReadOnly Property ID As Integer
            Get
                Return ID_
            End Get
        End Property
#End Region
#Region "CourseName_"
        Private CourseName_ As String
        Public Property [CourseName] As String
            Get
                Return CourseName_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CourseName from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CourseName_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [CourseName] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CourseName_ = value
            End Set
        End Property
#End Region
#Region "DegreeCategory_"
        Private DegreeCategory_ As String
        Public Property [DegreeCategory] As String
            Get
                Return DegreeCategory_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select DegreeCategory from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).DegreeCategory_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [DegreeCategory] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                DegreeCategory_ = value
            End Set
        End Property
#End Region
#Region "Professor_"
        Private Professor_ As String
        Public Property [Professor] As String
            Get
                Return Professor_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Professor from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Professor_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [Professor] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Professor_ = value
            End Set
        End Property
#End Region
#Region "Building_"
        Private Building_ As String
        Public Property [Building] As String
            Get
                Return Building_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Building from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Building_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [Building] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Building_ = value
            End Set
        End Property
#End Region
#Region "RoomNumber_"
        Private RoomNumber_ As String
        Public Property [RoomNumber] As String
            Get
                Return RoomNumber_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select RoomNumber from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).RoomNumber_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [RoomNumber] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                RoomNumber_ = value
            End Set
        End Property
#End Region
#Region "DaysOfWeek_"
        Private DaysOfWeek_ As String
        Public Property [DaysOfWeek] As String
            Get
                Return DaysOfWeek_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select DaysOfWeek from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).DaysOfWeek_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [DaysOfWeek] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                DaysOfWeek_ = value
            End Set
        End Property
#End Region
#Region "SessionStart_"
        Private SessionStart_ As Date
        Public Property [SessionStart] As Date
            Get
                Return SessionStart_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select SessionStart from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).SessionStart_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [SessionStart] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                SessionStart_ = value
            End Set
        End Property
#End Region
#Region "SessionEnd_"
        Private SessionEnd_ As Date
        Public Property [SessionEnd] As Date
            Get
                Return SessionEnd_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select SessionEnd from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).SessionEnd_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [SessionEnd] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                SessionEnd_ = value
            End Set
        End Property
#End Region
#Region "Startdate_"
        Private Startdate_ As Date
        Public Property [Startdate] As Date
            Get
                Return Startdate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Startdate from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Startdate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [Startdate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Startdate_ = value
            End Set
        End Property
#End Region
#Region "Enddate_"
        Private Enddate_ As Date
        Public Property [Enddate] As Date
            Get
                Return Enddate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Enddate from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Enddate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [Enddate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Enddate_ = value
            End Set
        End Property
#End Region
#Region "Credits_"
        Private Credits_ As Integer
        Public Property [Credits] As Integer
            Get
                Return Credits_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Credits from Courses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Credits_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Courses]
set [Credits] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Credits_ = value
            End Set
        End Property
#End Region
#End Region

#Region "Functions"
        ''' <summary>
        ''' This is a list of properties that has been used in your select statments
        ''' </summary>
        Public Shared UsedProperties As New List(Of String)()
        ''' <summary>
        ''' This Function allows you to use a sql query as an input to return a list of class records from the sql table in question. By setting the allow_update to true it 
        ''' will default all the records to allow real time transaction updates to the property changes based on the record ID. Keep in mind you must have an ID in the record for the update 
        ''' to work. This function not case sensative. If you are having trouble check DBIO stored quieres for a sessions transaction log. 
        ''' </summary>
        ''' <param name="qString">SQL statment here remember this will only fill properties that match exactly to the datacolumns returned in the sql statment</param>
        ''' <param name="allow_update">activates the update gate allowing real time transactions </param>
        ''' <returns></returns>
        Public Shared Function GetClass_table(qString As String, Optional allow_update As Boolean = False) As List(Of Courses)
            Dim L1 As New List(Of Courses)()
            Dim dt = DBIO.DirectQuery(qString)
            For Each row As DataRow In dt.Rows
                Try
                    Dim CL As New Courses(row)
                    CL.AllowUpdate = allow_update
                    L1.Add(CL)
                Catch ex As Exception
                    Console.WriteLine(ex.Message)
                End Try
            Next
            Return L1
        End Function
        ''' <summary>
        ''' creates a blank record so you can fill and use as a proxy or placeholder. 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' converts datarow to new class record must match datacolumn name with property name 
        ''' </summary>
        ''' <param name="DR">sql datarow</param>
        Public Sub New(DR As DataRow)
            Dim selected_columns As List(Of String) = DR.Table.Columns.Cast(Of DataColumn).Select(Function(x) x.ColumnName.ToUpper).ToList
            For Each pp In selected_columns.FindAll(Function(x) UsedProperties.Contains(x.ToUpper) = False)
                UsedProperties.Add(pp.ToUpper)
            Next
            Dim selected_properties As List(Of String) = Me.GetType.GetProperties.Select(Function(x) x.Name.ToUpper).ToList
            For Each P As PropertyInfo In Me.GetType.GetProperties.ToList.FindAll(Function(x) selected_columns.Contains(x.Name.ToUpper) = True)
                If selected_columns.Contains(P.Name.ToUpper) = True Then
                    Try
                        If P.Name = "ID" Then
                            ID_ = DR.Item("ID")
                            GoTo nextP
                        End If
                        If P.Name = "A4GLIdentity" Then
                            ID_ = DR.Item("A4GLIdentity")
                            GoTo nextP
                        End If
                    Catch ex As Exception

                    End Try
                    Try
                        P = CastProperty(Me,
  P,
  DR)
                    Catch ex As Exception
                        Console.WriteLine(Me.GetType.Name & ex.Message)
                    End Try
                End If
nextP:
            Next P
            Dim ppp = Me
        End Sub
        ''' <summary>
        ''' This  is a helper function that sets the values of the properties based on the datarow cell 
        ''' in the case of nulls it handles each datatype differntly 
        ''' 
        ''' </summary>
        ''' <param name="record">class record being filled</param>
        ''' <param name="p">class property being filled</param>
        ''' <param name="I">raw datarow </param>
        ''' <returns></returns>
        Public Shared Function CastProperty(record As Object,
                                      p As PropertyInfo,
                                       I As DataRow
                                                   ) As PropertyInfo
            Try
                Dim isNull As Boolean = IsDBNull(I.Item(p.Name))
                Select Case isNull
                    Case False
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, CDbl(I.Item((p.Name))))
                            Case GetType(Decimal).Name
                                p.SetValue(record, CDec(I.Item((p.Name))))
                            Case GetType(Date).Name
                                p.SetValue(record, CDate(I.Item((p.Name)).Date))
                            Case GetType(DateTime).Name
                                p.SetValue(record, CDate(I.Item((p.Name))))
                            Case GetType(String).Name
                                p.SetValue(record, CStr(I.Item((p.Name))).Trim)
                            Case GetType(Integer).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int32).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(I.Item((p.Name))))
                            Case Else
                                p.SetValue(record, I.Item((p.Name)))
                        End Select
                    Case True
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, 0)
                            Case GetType(Decimal).Name
                                p.SetValue(record, 0)
                            Case GetType(Date).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(DateTime).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(String).Name
                                p.SetValue(record, "")
                            Case GetType(Integer).Name
                                p.SetValue(record, 0)
                            Case GetType(Int32).Name
                                p.SetValue(record, 0)
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(0))
                            Case Else
                                p.SetValue(record, I.Item(p.Name))
                        End Select
                End Select
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try
            Console.WriteLine(p.GetValue(record))
            Return p
        End Function
        ''' <summary>
        ''' Auto generates a SQL insert statment based on the class record you insert only populating columns in which have SQL 
        ''' CAUTION: SQL data constraints still apply 
        ''' </summary>
        ''' <param name="record"></param>
        ''' <returns>returns select top 1 * order by ID desc </returns>
        Public Shared Function InsertRecord(record As Courses, Optional returnme As Boolean = False) As Courses
            Dim Headers As New List(Of String)()
            Dim values As New List(Of String)()
            Dim H_string As String = "(" & vbNewLine
            Dim V_string As String = "Values ( " & vbNewLine
            Dim first_record As Boolean = True
            For Each p As PropertyInfo In record.GetType.GetProperties.ToList.FindAll(Function(x As PropertyInfo) x.GetValue(record) <> Nothing)

                Headers.Add(p.Name)
                values.Add(p.GetValue(record))
                Select Case first_record
                    Case True
                        H_string += "[" & p.Name & "]" & vbNewLine
                        V_string += "'" & p.GetValue(record) & "'" & vbNewLine
                    Case False
                        H_string += "," & "[" & p.Name & "]" & vbNewLine
                        V_string += "," & "'" & p.GetValue(record) & "'" & vbNewLine
                End Select
                first_record = False
            Next p
            H_string += vbNewLine & ")"
            V_string += vbNewLine & ")"
            Dim cmd_string = "Insert into Courses " & vbNewLine & H_string & vbNewLine & V_string
            Dim cmd = DBIO.DirectCommand(cmd_string)
            If cmd = Nothing Then
                Try
                    If returnme = True Then
                        record = GetClass_table("Select top 1 * From Courses Order by ID desc ")(0)
                        Return record
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception

                End Try
            End If
        End Function
        Function Update_all_fields(Columns As List(Of CoursesColumns), Optional Allcolumns As Boolean = False) As String

            Dim record As Courses = Me
            If record.ID = 0 Then Exit Function
            If record.ID = Nothing Then Exit Function

            Dim cmd_str = "
Update Courses 
SET

{FIELDS}

Where ID = " & record.ID & "
"
            If Allcolumns = True Then
                Columns = New List(Of CoursesColumns)()
                For Each c In System.Enum.GetValues(GetType(CoursesColumns))
                    Columns.Add(c)
                Next
            End If
            Dim C_names As New List(Of String)()
            For Each c In Columns
                C_names.Add(c.ToString)
            Next
            Dim Fields_string As String = Nothing
            Dim gList = record.GetType.GetProperties.ToList.FindAll(Function(x) C_names.Contains(x.Name))
            Dim pLimit = gList.Count - 1
            Dim pCount = 0
            For Each P As PropertyInfo In gList
                pCount += 1
                Try
                    If P.Name = "AllowUpdate" Then
                        GoTo nextP
                    End If

                    If P.Name = "ID" Then
                        GoTo nextP
                    Else
                        Select Case pCount
                            Case 1
                                Fields_string = P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                            Case Else
                                Fields_string += "," & P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                        End Select
                    End If
                Catch ex As Exception

                End Try
nextP:
            Next P
            cmd_str = cmd_str.Replace("{FIELDS}", Fields_string)
            '  MsgBox(cmd_str)
            Dim CMD_output = DBIO.DirectCommand(cmd_str)
            Return CMD_output
        End Function
#End Region
    End Class


    ''' <summary>
    ''' This is a reflection of [CourseManagement].[dbo].[Student], it mirrors all the columns as properties and converts sql dbtypes to vb data types.
    ''' With this class you can insert, select and update records without having to write out the sql statments. 
    ''' </summary>
    Public Class Student
        Enum StudentColumns
            [ID] = 0
            [FirstName] = 1
            [LastName] = 2
            [DOB] = 3
            [Sex] = 4
            [EnrollmentDate] = 5
            [CumulativeGPA] = 6
            [SemesterGPA] = 7
            [Credits] = 8
            [CurrentHours] = 9
            [CourseDropCount] = 10
            [Field_of_study] = 11
            [Major] = 12
            [Minor] = 13
            [AccountBalance] = 14
            [PassWordHash] = 15
        End Enum

#Region "VARS"
        Property [AllowUpdate] As Boolean
#Region "ID_"
        Private Property ID_ As Integer
        ReadOnly Property ID As Integer
            Get
                Return ID_
            End Get
        End Property
#End Region
#Region "FirstName_"
        Private FirstName_ As String
        Public Property [FirstName] As String
            Get
                Return FirstName_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select FirstName from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).FirstName_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [FirstName] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                FirstName_ = value
            End Set
        End Property
#End Region
#Region "LastName_"
        Private LastName_ As String
        Public Property [LastName] As String
            Get
                Return LastName_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select LastName from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).LastName_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [LastName] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                LastName_ = value
            End Set
        End Property
#End Region
#Region "DOB_"
        Private DOB_ As Date
        Public Property [DOB] As Date
            Get
                Return DOB_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select DOB from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).DOB_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [DOB] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                DOB_ = value
            End Set
        End Property
#End Region
#Region "Sex_"
        Private Sex_ As String
        Public Property [Sex] As String
            Get
                Return Sex_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Sex from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Sex_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [Sex] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Sex_ = value
            End Set
        End Property
#End Region
#Region "EnrollmentDate_"
        Private EnrollmentDate_ As Date
        Public Property [EnrollmentDate] As Date
            Get
                Return EnrollmentDate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select EnrollmentDate from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).EnrollmentDate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [EnrollmentDate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                EnrollmentDate_ = value
            End Set
        End Property
#End Region
#Region "CumulativeGPA_"
        Private CumulativeGPA_ As Double
        Public Property [CumulativeGPA] As Double
            Get
                Return CumulativeGPA_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CumulativeGPA from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CumulativeGPA_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [CumulativeGPA] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CumulativeGPA_ = value
            End Set
        End Property
#End Region
#Region "SemesterGPA_"
        Private SemesterGPA_ As Double
        Public Property [SemesterGPA] As Double
            Get
                Return SemesterGPA_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select SemesterGPA from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).SemesterGPA_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [SemesterGPA] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                SemesterGPA_ = value
            End Set
        End Property
#End Region
#Region "Credits_"
        Private Credits_ As Double
        Public Property [Credits] As Double
            Get
                Return Credits_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Credits from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Credits_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [Credits] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Credits_ = value
            End Set
        End Property
#End Region
#Region "CurrentHours_"
        Private CurrentHours_ As Double
        Public Property [CurrentHours] As Double
            Get
                Return CurrentHours_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CurrentHours from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CurrentHours_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [CurrentHours] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CurrentHours_ = value
            End Set
        End Property
#End Region
#Region "CourseDropCount_"
        Private CourseDropCount_ As Integer
        Public Property [CourseDropCount] As Integer
            Get
                Return CourseDropCount_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CourseDropCount from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CourseDropCount_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [CourseDropCount] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CourseDropCount_ = value
            End Set
        End Property
#End Region
#Region "Field_of_study_"
        Private Field_of_study_ As String
        Public Property [Field_of_study] As String
            Get
                Return Field_of_study_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Field_of_study from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Field_of_study_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [Field_of_study] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Field_of_study_ = value
            End Set
        End Property
#End Region
#Region "Major_"
        Private Major_ As String
        Public Property [Major] As String
            Get
                Return Major_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Major from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Major_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [Major] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Major_ = value
            End Set
        End Property
#End Region
#Region "Minor_"
        Private Minor_ As String
        Public Property [Minor] As String
            Get
                Return Minor_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Minor from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Minor_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [Minor] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Minor_ = value
            End Set
        End Property
#End Region
#Region "AccountBalance_"
        Private AccountBalance_ As Integer
        Public Property [AccountBalance] As Integer
            Get
                Return AccountBalance_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select AccountBalance from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).AccountBalance_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [AccountBalance] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                AccountBalance_ = value
            End Set
        End Property
#End Region
#Region "PassWordHash_"
        Private PassWordHash_ As String
        Public Property [PassWordHash] As String
            Get
                Return PassWordHash_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select PassWordHash from Student where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).PassWordHash_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[Student]
set [PassWordHash] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                PassWordHash_ = value
            End Set
        End Property
#End Region
#End Region

#Region "Functions"
        ''' <summary>
        ''' This is a list of properties that has been used in your select statments
        ''' </summary>
        Public Shared UsedProperties As New List(Of String)()
        ''' <summary>
        ''' This Function allows you to use a sql query as an input to return a list of class records from the sql table in question. By setting the allow_update to true it 
        ''' will default all the records to allow real time transaction updates to the property changes based on the record ID. Keep in mind you must have an ID in the record for the update 
        ''' to work. This function not case sensative. If you are having trouble check DBIO stored quieres for a sessions transaction log. 
        ''' </summary>
        ''' <param name="qString">SQL statment here remember this will only fill properties that match exactly to the datacolumns returned in the sql statment</param>
        ''' <param name="allow_update">activates the update gate allowing real time transactions </param>
        ''' <returns></returns>
        Public Shared Function GetClass_table(qString As String, Optional allow_update As Boolean = False) As List(Of Student)
            Dim L1 As New List(Of Student)()
            Dim dt = DBIO.DirectQuery(qString)
            For Each row As DataRow In dt.Rows
                Try
                    Dim CL As New Student(row)
                    CL.AllowUpdate = allow_update
                    L1.Add(CL)
                Catch ex As Exception
                    Console.WriteLine(ex.Message)
                End Try
            Next
            Return L1
        End Function
        ''' <summary>
        ''' creates a blank record so you can fill and use as a proxy or placeholder. 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' converts datarow to new class record must match datacolumn name with property name 
        ''' </summary>
        ''' <param name="DR">sql datarow</param>
        Public Sub New(DR As DataRow)
            Dim selected_columns As List(Of String) = DR.Table.Columns.Cast(Of DataColumn).Select(Function(x) x.ColumnName.ToUpper).ToList
            For Each pp In selected_columns.FindAll(Function(x) UsedProperties.Contains(x.ToUpper) = False)
                UsedProperties.Add(pp.ToUpper)
            Next
            Dim selected_properties As List(Of String) = Me.GetType.GetProperties.Select(Function(x) x.Name.ToUpper).ToList
            For Each P As PropertyInfo In Me.GetType.GetProperties.ToList.FindAll(Function(x) selected_columns.Contains(x.Name.ToUpper) = True)
                If selected_columns.Contains(P.Name.ToUpper) = True Then
                    Try
                        If P.Name = "ID" Then
                            ID_ = DR.Item("ID")
                            GoTo nextP
                        End If
                        If P.Name = "A4GLIdentity" Then
                            ID_ = DR.Item("A4GLIdentity")
                            GoTo nextP
                        End If
                    Catch ex As Exception

                    End Try
                    Try
                        P = CastProperty(Me,
  P,
  DR)
                    Catch ex As Exception
                        Console.WriteLine(Me.GetType.Name & ex.Message)
                    End Try
                End If
nextP:
            Next P
            Dim ppp = Me
        End Sub
        ''' <summary>
        ''' This  is a helper function that sets the values of the properties based on the datarow cell 
        ''' in the case of nulls it handles each datatype differntly 
        ''' 
        ''' </summary>
        ''' <param name="record">class record being filled</param>
        ''' <param name="p">class property being filled</param>
        ''' <param name="I">raw datarow </param>
        ''' <returns></returns>
        Public Shared Function CastProperty(record As Object,
                                      p As PropertyInfo,
                                       I As DataRow
                                                   ) As PropertyInfo
            Try
                Dim isNull As Boolean = IsDBNull(I.Item(p.Name))
                Select Case isNull
                    Case False
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, CDbl(I.Item((p.Name))))
                            Case GetType(Decimal).Name
                                p.SetValue(record, CDec(I.Item((p.Name))))
                            Case GetType(Date).Name
                                p.SetValue(record, CDate(I.Item((p.Name)).Date))
                            Case GetType(DateTime).Name
                                p.SetValue(record, CDate(I.Item((p.Name))))
                            Case GetType(String).Name
                                p.SetValue(record, CStr(I.Item((p.Name))).Trim)
                            Case GetType(Integer).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int32).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(I.Item((p.Name))))
                            Case Else
                                p.SetValue(record, I.Item((p.Name)))
                        End Select
                    Case True
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, 0)
                            Case GetType(Decimal).Name
                                p.SetValue(record, 0)
                            Case GetType(Date).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(DateTime).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(String).Name
                                p.SetValue(record, "")
                            Case GetType(Integer).Name
                                p.SetValue(record, 0)
                            Case GetType(Int32).Name
                                p.SetValue(record, 0)
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(0))
                            Case Else
                                p.SetValue(record, I.Item(p.Name))
                        End Select
                End Select
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try
            Console.WriteLine(p.GetValue(record))
            Return p
        End Function
        ''' <summary>
        ''' Auto generates a SQL insert statment based on the class record you insert only populating columns in which have SQL 
        ''' CAUTION: SQL data constraints still apply 
        ''' </summary>
        ''' <param name="record"></param>
        ''' <returns>returns select top 1 * order by ID desc </returns>
        Public Shared Function InsertRecord(record As Student, Optional returnme As Boolean = False) As Student
            Dim Headers As New List(Of String)()
            Dim values As New List(Of String)()
            Dim H_string As String = "(" & vbNewLine
            Dim V_string As String = "Values ( " & vbNewLine
            Dim first_record As Boolean = True
            For Each p As PropertyInfo In record.GetType.GetProperties.ToList.FindAll(Function(x As PropertyInfo) x.GetValue(record) <> Nothing)

                Headers.Add(p.Name)
                values.Add(p.GetValue(record))
                Select Case first_record
                    Case True
                        H_string += "[" & p.Name & "]" & vbNewLine
                        V_string += "'" & p.GetValue(record) & "'" & vbNewLine
                    Case False
                        H_string += "," & "[" & p.Name & "]" & vbNewLine
                        V_string += "," & "'" & p.GetValue(record) & "'" & vbNewLine
                End Select
                first_record = False
            Next p
            H_string += vbNewLine & ")"
            V_string += vbNewLine & ")"
            Dim cmd_string = "Insert into Student " & vbNewLine & H_string & vbNewLine & V_string
            Dim cmd = DBIO.DirectCommand(cmd_string)
            If cmd = Nothing Then
                Try
                    If returnme = True Then
                        record = GetClass_table("Select top 1 * From Student Order by ID desc ")(0)
                        Return record
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception

                End Try
            End If
        End Function
        Function Update_all_fields(Columns As List(Of StudentColumns), Optional Allcolumns As Boolean = False) As String

            Dim record As Student = Me
            If record.ID = 0 Then Exit Function
            If record.ID = Nothing Then Exit Function

            Dim cmd_str = "
Update Student 
SET

{FIELDS}

Where ID = " & record.ID & "
"
            If Allcolumns = True Then
                Columns = New List(Of StudentColumns)()
                For Each c In System.Enum.GetValues(GetType(StudentColumns))
                    Columns.Add(c)
                Next
            End If
            Dim C_names As New List(Of String)()
            For Each c In Columns
                C_names.Add(c.ToString)
            Next
            Dim Fields_string As String = Nothing
            Dim gList = record.GetType.GetProperties.ToList.FindAll(Function(x) C_names.Contains(x.Name))
            Dim pLimit = gList.Count - 1
            Dim pCount = 0
            For Each P As PropertyInfo In gList
                pCount += 1
                Try
                    If P.Name = "AllowUpdate" Then
                        GoTo nextP
                    End If

                    If P.Name = "ID" Then
                        GoTo nextP
                    Else
                        Select Case pCount
                            Case 1
                                Fields_string = P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                            Case Else
                                Fields_string += "," & P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                        End Select
                    End If
                Catch ex As Exception

                End Try
nextP:
            Next P
            cmd_str = cmd_str.Replace("{FIELDS}", Fields_string)
            '  MsgBox(cmd_str)
            Dim CMD_output = DBIO.DirectCommand(cmd_str)
            Return CMD_output
        End Function
#End Region
    End Class


    ''' <summary>
    ''' This is a reflection of [CourseManagement].[dbo].[StudentCourseGrades], it mirrors all the columns as properties and converts sql dbtypes to vb data types.
    ''' With this class you can insert, select and update records without having to write out the sql statments. 
    ''' </summary>
    Public Class StudentCourseGrades
        Enum StudentCourseGradesColumns
            [ID] = 0
            [StudentID] = 1
            [StudentCourseID] = 2
            [CourseID] = 3
            [AssignmentName] = 4
            [Grade] = 5
            [GradeGPA] = 6
            [GradeWeight] = 7
            [Assigneddate] = 8
            [Duedate] = 9
            [Passed] = 10
        End Enum

#Region "VARS"
        Property [AllowUpdate] As Boolean
#Region "ID_"
        Private Property ID_ As Integer
        ReadOnly Property ID As Integer
            Get
                Return ID_
            End Get
        End Property
#End Region
#Region "StudentID_"
        Private StudentID_ As Integer
        Public Property [StudentID] As Integer
            Get
                Return StudentID_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select StudentID from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).StudentID_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [StudentID] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                StudentID_ = value
            End Set
        End Property
#End Region
#Region "StudentCourseID_"
        Private StudentCourseID_ As Integer
        Public Property [StudentCourseID] As Integer
            Get
                Return StudentCourseID_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select StudentCourseID from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).StudentCourseID_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [StudentCourseID] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                StudentCourseID_ = value
            End Set
        End Property
#End Region
#Region "CourseID_"
        Private CourseID_ As Integer
        Public Property [CourseID] As Integer
            Get
                Return CourseID_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CourseID from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CourseID_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [CourseID] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CourseID_ = value
            End Set
        End Property
#End Region
#Region "AssignmentName_"
        Private AssignmentName_ As String
        Public Property [AssignmentName] As String
            Get
                Return AssignmentName_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select AssignmentName from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).AssignmentName_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [AssignmentName] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                AssignmentName_ = value
            End Set
        End Property
#End Region
#Region "Grade_"
        Private Grade_ As Double
        Public Property [Grade] As Double
            Get
                Return Grade_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Grade from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Grade_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [Grade] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Grade_ = value
            End Set
        End Property
#End Region
#Region "GradeGPA_"
        Private GradeGPA_ As Double
        Public Property [GradeGPA] As Double
            Get
                Return GradeGPA_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select GradeGPA from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).GradeGPA_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [GradeGPA] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                GradeGPA_ = value
            End Set
        End Property
#End Region
#Region "GradeWeight_"
        Private GradeWeight_ As Double
        Public Property [GradeWeight] As Double
            Get
                Return GradeWeight_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select GradeWeight from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).GradeWeight_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [GradeWeight] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                GradeWeight_ = value
            End Set
        End Property
#End Region
#Region "Assigneddate_"
        Private Assigneddate_ As Date
        Public Property [Assigneddate] As Date
            Get
                Return Assigneddate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Assigneddate from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Assigneddate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [Assigneddate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Assigneddate_ = value
            End Set
        End Property
#End Region
#Region "Duedate_"
        Private Duedate_ As Date
        Public Property [Duedate] As Date
            Get
                Return Duedate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Duedate from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Duedate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [Duedate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Duedate_ = value
            End Set
        End Property
#End Region
#Region "Passed_"
        Private Passed_ As String
        Public Property [Passed] As String
            Get
                Return Passed_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Passed from StudentCourseGrades where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Passed_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourseGrades]
set [Passed] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Passed_ = value
            End Set
        End Property
#End Region
#End Region

#Region "Functions"
        ''' <summary>
        ''' This is a list of properties that has been used in your select statments
        ''' </summary>
        Public Shared UsedProperties As New List(Of String)()
        ''' <summary>
        ''' This Function allows you to use a sql query as an input to return a list of class records from the sql table in question. By setting the allow_update to true it 
        ''' will default all the records to allow real time transaction updates to the property changes based on the record ID. Keep in mind you must have an ID in the record for the update 
        ''' to work. This function not case sensative. If you are having trouble check DBIO stored quieres for a sessions transaction log. 
        ''' </summary>
        ''' <param name="qString">SQL statment here remember this will only fill properties that match exactly to the datacolumns returned in the sql statment</param>
        ''' <param name="allow_update">activates the update gate allowing real time transactions </param>
        ''' <returns></returns>
        Public Shared Function GetClass_table(qString As String, Optional allow_update As Boolean = False) As List(Of StudentCourseGrades)
            Dim L1 As New List(Of StudentCourseGrades)()
            Dim dt = DBIO.DirectQuery(qString)
            For Each row As DataRow In dt.Rows
                Try
                    Dim CL As New StudentCourseGrades(row)
                    CL.AllowUpdate = allow_update
                    L1.Add(CL)
                Catch ex As Exception
                    Console.WriteLine(ex.Message)
                End Try
            Next
            Return L1
        End Function
        ''' <summary>
        ''' creates a blank record so you can fill and use as a proxy or placeholder. 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' converts datarow to new class record must match datacolumn name with property name 
        ''' </summary>
        ''' <param name="DR">sql datarow</param>
        Public Sub New(DR As DataRow)
            Dim selected_columns As List(Of String) = DR.Table.Columns.Cast(Of DataColumn).Select(Function(x) x.ColumnName.ToUpper).ToList
            For Each pp In selected_columns.FindAll(Function(x) UsedProperties.Contains(x.ToUpper) = False)
                UsedProperties.Add(pp.ToUpper)
            Next
            Dim selected_properties As List(Of String) = Me.GetType.GetProperties.Select(Function(x) x.Name.ToUpper).ToList
            For Each P As PropertyInfo In Me.GetType.GetProperties.ToList.FindAll(Function(x) selected_columns.Contains(x.Name.ToUpper) = True)
                If selected_columns.Contains(P.Name.ToUpper) = True Then
                    Try
                        If P.Name = "ID" Then
                            ID_ = DR.Item("ID")
                            GoTo nextP
                        End If
                        If P.Name = "A4GLIdentity" Then
                            ID_ = DR.Item("A4GLIdentity")
                            GoTo nextP
                        End If
                    Catch ex As Exception

                    End Try
                    Try
                        P = CastProperty(Me,
  P,
  DR)
                    Catch ex As Exception
                        Console.WriteLine(Me.GetType.Name & ex.Message)
                    End Try
                End If
nextP:
            Next P
            Dim ppp = Me
        End Sub
        ''' <summary>
        ''' This  is a helper function that sets the values of the properties based on the datarow cell 
        ''' in the case of nulls it handles each datatype differntly 
        ''' 
        ''' </summary>
        ''' <param name="record">class record being filled</param>
        ''' <param name="p">class property being filled</param>
        ''' <param name="I">raw datarow </param>
        ''' <returns></returns>
        Public Shared Function CastProperty(record As Object,
                                      p As PropertyInfo,
                                       I As DataRow
                                                   ) As PropertyInfo
            Try
                Dim isNull As Boolean = IsDBNull(I.Item(p.Name))
                Select Case isNull
                    Case False
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, CDbl(I.Item((p.Name))))
                            Case GetType(Decimal).Name
                                p.SetValue(record, CDec(I.Item((p.Name))))
                            Case GetType(Date).Name
                                p.SetValue(record, CDate(I.Item((p.Name)).Date))
                            Case GetType(DateTime).Name
                                p.SetValue(record, CDate(I.Item((p.Name))))
                            Case GetType(String).Name
                                p.SetValue(record, CStr(I.Item((p.Name))).Trim)
                            Case GetType(Integer).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int32).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(I.Item((p.Name))))
                            Case Else
                                p.SetValue(record, I.Item((p.Name)))
                        End Select
                    Case True
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, 0)
                            Case GetType(Decimal).Name
                                p.SetValue(record, 0)
                            Case GetType(Date).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(DateTime).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(String).Name
                                p.SetValue(record, "")
                            Case GetType(Integer).Name
                                p.SetValue(record, 0)
                            Case GetType(Int32).Name
                                p.SetValue(record, 0)
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(0))
                            Case Else
                                p.SetValue(record, I.Item(p.Name))
                        End Select
                End Select
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try
            Console.WriteLine(p.GetValue(record))
            Return p
        End Function
        ''' <summary>
        ''' Auto generates a SQL insert statment based on the class record you insert only populating columns in which have SQL 
        ''' CAUTION: SQL data constraints still apply 
        ''' </summary>
        ''' <param name="record"></param>
        ''' <returns>returns select top 1 * order by ID desc </returns>
        Public Shared Function InsertRecord(record As StudentCourseGrades, Optional returnme As Boolean = False) As StudentCourseGrades
            Dim Headers As New List(Of String)()
            Dim values As New List(Of String)()
            Dim H_string As String = "(" & vbNewLine
            Dim V_string As String = "Values ( " & vbNewLine
            Dim first_record As Boolean = True
            For Each p As PropertyInfo In record.GetType.GetProperties.ToList.FindAll(Function(x As PropertyInfo) x.GetValue(record) <> Nothing)

                Headers.Add(p.Name)
                values.Add(p.GetValue(record))
                Select Case first_record
                    Case True
                        H_string += "[" & p.Name & "]" & vbNewLine
                        V_string += "'" & p.GetValue(record) & "'" & vbNewLine
                    Case False
                        H_string += "," & "[" & p.Name & "]" & vbNewLine
                        V_string += "," & "'" & p.GetValue(record) & "'" & vbNewLine
                End Select
                first_record = False
            Next p
            H_string += vbNewLine & ")"
            V_string += vbNewLine & ")"
            Dim cmd_string = "Insert into StudentCourseGrades " & vbNewLine & H_string & vbNewLine & V_string
            Dim cmd = DBIO.DirectCommand(cmd_string)
            If cmd = Nothing Then
                Try
                    If returnme = True Then
                        record = GetClass_table("Select top 1 * From StudentCourseGrades Order by ID desc ")(0)
                        Return record
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception

                End Try
            End If
        End Function
        Function Update_all_fields(Columns As List(Of StudentCourseGradesColumns), Optional Allcolumns As Boolean = False) As String

            Dim record As StudentCourseGrades = Me
            If record.ID = 0 Then Exit Function
            If record.ID = Nothing Then Exit Function

            Dim cmd_str = "
Update StudentCourseGrades 
SET

{FIELDS}

Where ID = " & record.ID & "
"
            If Allcolumns = True Then
                Columns = New List(Of StudentCourseGradesColumns)()
                For Each c In System.Enum.GetValues(GetType(StudentCourseGradesColumns))
                    Columns.Add(c)
                Next
            End If
            Dim C_names As New List(Of String)()
            For Each c In Columns
                C_names.Add(c.ToString)
            Next
            Dim Fields_string As String = Nothing
            Dim gList = record.GetType.GetProperties.ToList.FindAll(Function(x) C_names.Contains(x.Name))
            Dim pLimit = gList.Count - 1
            Dim pCount = 0
            For Each P As PropertyInfo In gList
                pCount += 1
                Try
                    If P.Name = "AllowUpdate" Then
                        GoTo nextP
                    End If

                    If P.Name = "ID" Then
                        GoTo nextP
                    Else
                        Select Case pCount
                            Case 1
                                Fields_string = P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                            Case Else
                                Fields_string += "," & P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                        End Select
                    End If
                Catch ex As Exception

                End Try
nextP:
            Next P
            cmd_str = cmd_str.Replace("{FIELDS}", Fields_string)
            '  MsgBox(cmd_str)
            Dim CMD_output = DBIO.DirectCommand(cmd_str)
            Return CMD_output
        End Function
#End Region
    End Class


    ''' <summary>
    ''' This is a reflection of [CourseManagement].[dbo].[StudentCourses], it mirrors all the columns as properties and converts sql dbtypes to vb data types.
    ''' With this class you can insert, select and update records without having to write out the sql statments. 
    ''' </summary>
    Public Class StudentCourses
        Enum StudentCoursesColumns
            [ID] = 0
            [StudentID] = 1
            [CourseID] = 2
            [GPA] = 3
            [Startdate] = 4
            [Enddate] = 5
            [Credits] = 6
            [Active] = 7
            [Passed] = 8
        End Enum

#Region "VARS"
        Property [AllowUpdate] As Boolean
#Region "ID_"
        Private Property ID_ As Integer
        ReadOnly Property ID As Integer
            Get
                Return ID_
            End Get
        End Property
#End Region
#Region "StudentID_"
        Private StudentID_ As Integer
        Public Property [StudentID] As Integer
            Get
                Return StudentID_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select StudentID from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).StudentID_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [StudentID] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                StudentID_ = value
            End Set
        End Property
#End Region
#Region "CourseID_"
        Private CourseID_ As Integer
        Public Property [CourseID] As Integer
            Get
                Return CourseID_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select CourseID from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).CourseID_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [CourseID] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                CourseID_ = value
            End Set
        End Property
#End Region
#Region "GPA_"
        Private GPA_ As Double
        Public Property [GPA] As Double
            Get
                Return GPA_
            End Get
            Set(value As Double)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select GPA from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).GPA_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [GPA] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                GPA_ = value
            End Set
        End Property
#End Region
#Region "Startdate_"
        Private Startdate_ As Date
        Public Property [Startdate] As Date
            Get
                Return Startdate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Startdate from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Startdate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [Startdate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Startdate_ = value
            End Set
        End Property
#End Region
#Region "Enddate_"
        Private Enddate_ As Date
        Public Property [Enddate] As Date
            Get
                Return Enddate_
            End Get
            Set(value As Date)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Enddate from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Enddate_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [Enddate] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Enddate_ = value
            End Set
        End Property
#End Region
#Region "Credits_"
        Private Credits_ As Integer
        Public Property [Credits] As Integer
            Get
                Return Credits_
            End Get
            Set(value As Integer)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Credits from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Credits_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [Credits] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Credits_ = value
            End Set
        End Property
#End Region
#Region "Active_"
        Private Active_ As String
        Public Property [Active] As String
            Get
                Return Active_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Active from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Active_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [Active] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Active_ = value
            End Set
        End Property
#End Region
#Region "Passed_"
        Private Passed_ As String
        Public Property [Passed] As String
            Get
                Return Passed_
            End Get
            Set(value As String)
                Try
                    If AllowUpdate = True Then
                        Dim qCheck = GetClass_table(" Select Passed from StudentCourses where ID = " & ID)
                        If qCheck.Count = 1 Then
                            If qCheck(0).Passed_ <> value Then
                                Dim CMD_string = ("
Update [CourseManagement].[dbo].[StudentCourses]
set [Passed] = '" & value & "'
Where ID = " & ID)
                                Console.WriteLine(CMD_string)
                                Dim CMD = DBIO.DirectCommand(CMD_string)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try
                Passed_ = value
            End Set
        End Property
#End Region
#End Region

#Region "Functions"
        ''' <summary>
        ''' This is a list of properties that has been used in your select statments
        ''' </summary>
        Public Shared UsedProperties As New List(Of String)()
        ''' <summary>
        ''' This Function allows you to use a sql query as an input to return a list of class records from the sql table in question. By setting the allow_update to true it 
        ''' will default all the records to allow real time transaction updates to the property changes based on the record ID. Keep in mind you must have an ID in the record for the update 
        ''' to work. This function not case sensative. If you are having trouble check DBIO stored quieres for a sessions transaction log. 
        ''' </summary>
        ''' <param name="qString">SQL statment here remember this will only fill properties that match exactly to the datacolumns returned in the sql statment</param>
        ''' <param name="allow_update">activates the update gate allowing real time transactions </param>
        ''' <returns></returns>
        Public Shared Function GetClass_table(qString As String, Optional allow_update As Boolean = False) As List(Of StudentCourses)
            Dim L1 As New List(Of StudentCourses)()
            Dim dt = DBIO.DirectQuery(qString)
            For Each row As DataRow In dt.Rows
                Try
                    Dim CL As New StudentCourses(row)
                    CL.AllowUpdate = allow_update
                    L1.Add(CL)
                Catch ex As Exception
                    Console.WriteLine(ex.Message)
                End Try
            Next
            Return L1
        End Function
        ''' <summary>
        ''' creates a blank record so you can fill and use as a proxy or placeholder. 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' converts datarow to new class record must match datacolumn name with property name 
        ''' </summary>
        ''' <param name="DR">sql datarow</param>
        Public Sub New(DR As DataRow)
            Dim selected_columns As List(Of String) = DR.Table.Columns.Cast(Of DataColumn).Select(Function(x) x.ColumnName.ToUpper).ToList
            For Each pp In selected_columns.FindAll(Function(x) UsedProperties.Contains(x.ToUpper) = False)
                UsedProperties.Add(pp.ToUpper)
            Next
            Dim selected_properties As List(Of String) = Me.GetType.GetProperties.Select(Function(x) x.Name.ToUpper).ToList
            For Each P As PropertyInfo In Me.GetType.GetProperties.ToList.FindAll(Function(x) selected_columns.Contains(x.Name.ToUpper) = True)
                If selected_columns.Contains(P.Name.ToUpper) = True Then
                    Try
                        If P.Name = "ID" Then
                            ID_ = DR.Item("ID")
                            GoTo nextP
                        End If
                        If P.Name = "A4GLIdentity" Then
                            ID_ = DR.Item("A4GLIdentity")
                            GoTo nextP
                        End If
                    Catch ex As Exception

                    End Try
                    Try
                        P = CastProperty(Me,
  P,
  DR)
                    Catch ex As Exception
                        Console.WriteLine(Me.GetType.Name & ex.Message)
                    End Try
                End If
nextP:
            Next P
            Dim ppp = Me
        End Sub
        ''' <summary>
        ''' This  is a helper function that sets the values of the properties based on the datarow cell 
        ''' in the case of nulls it handles each datatype differntly 
        ''' 
        ''' </summary>
        ''' <param name="record">class record being filled</param>
        ''' <param name="p">class property being filled</param>
        ''' <param name="I">raw datarow </param>
        ''' <returns></returns>
        Public Shared Function CastProperty(record As Object,
                                      p As PropertyInfo,
                                       I As DataRow
                                                   ) As PropertyInfo
            Try
                Dim isNull As Boolean = IsDBNull(I.Item(p.Name))
                Select Case isNull
                    Case False
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, CDbl(I.Item((p.Name))))
                            Case GetType(Decimal).Name
                                p.SetValue(record, CDec(I.Item((p.Name))))
                            Case GetType(Date).Name
                                p.SetValue(record, CDate(I.Item((p.Name)).Date))
                            Case GetType(DateTime).Name
                                p.SetValue(record, CDate(I.Item((p.Name))))
                            Case GetType(String).Name
                                p.SetValue(record, CStr(I.Item((p.Name))).Trim)
                            Case GetType(Integer).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int32).Name
                                p.SetValue(record, CInt(I.Item((p.Name))))
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(I.Item((p.Name))))
                            Case Else
                                p.SetValue(record, I.Item((p.Name)))
                        End Select
                    Case True
                        Select Case p.PropertyType.Name
                            Case GetType(Double).Name
                                p.SetValue(record, 0)
                            Case GetType(Decimal).Name
                                p.SetValue(record, 0)
                            Case GetType(Date).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(DateTime).Name
                                p.SetValue(record, Now.AddYears(-50))
                            Case GetType(String).Name
                                p.SetValue(record, "")
                            Case GetType(Integer).Name
                                p.SetValue(record, 0)
                            Case GetType(Int32).Name
                                p.SetValue(record, 0)
                            Case GetType(Int16).Name
                                p.SetValue(record, Convert.ToInt16(0))
                            Case Else
                                p.SetValue(record, I.Item(p.Name))
                        End Select
                End Select
            Catch ex As Exception
                Console.WriteLine(ex.Message)
            End Try
            Console.WriteLine(p.GetValue(record))
            Return p
        End Function
        ''' <summary>
        ''' Auto generates a SQL insert statment based on the class record you insert only populating columns in which have SQL 
        ''' CAUTION: SQL data constraints still apply 
        ''' </summary>
        ''' <param name="record"></param>
        ''' <returns>returns select top 1 * order by ID desc </returns>
        Public Shared Function InsertRecord(record As StudentCourses, Optional returnme As Boolean = False) As StudentCourses
            Dim Headers As New List(Of String)()
            Dim values As New List(Of String)()
            Dim H_string As String = "(" & vbNewLine
            Dim V_string As String = "Values ( " & vbNewLine
            Dim first_record As Boolean = True
            For Each p As PropertyInfo In record.GetType.GetProperties.ToList.FindAll(Function(x As PropertyInfo) x.GetValue(record) <> Nothing)

                Headers.Add(p.Name)
                values.Add(p.GetValue(record))
                Select Case first_record
                    Case True
                        H_string += "[" & p.Name & "]" & vbNewLine
                        V_string += "'" & p.GetValue(record) & "'" & vbNewLine
                    Case False
                        H_string += "," & "[" & p.Name & "]" & vbNewLine
                        V_string += "," & "'" & p.GetValue(record) & "'" & vbNewLine
                End Select
                first_record = False
            Next p
            H_string += vbNewLine & ")"
            V_string += vbNewLine & ")"
            Dim cmd_string = "Insert into StudentCourses " & vbNewLine & H_string & vbNewLine & V_string
            Dim cmd = DBIO.DirectCommand(cmd_string)
            If cmd = Nothing Then
                Try
                    If returnme = True Then
                        record = GetClass_table("Select top 1 * From StudentCourses Order by ID desc ")(0)
                        Return record
                    Else
                        Return Nothing
                    End If
                Catch ex As Exception

                End Try
            End If
        End Function
        Function Update_all_fields(Columns As List(Of StudentCoursesColumns), Optional Allcolumns As Boolean = False) As String

            Dim record As StudentCourses = Me
            If record.ID = 0 Then Exit Function
            If record.ID = Nothing Then Exit Function

            Dim cmd_str = "
Update StudentCourses 
SET

{FIELDS}

Where ID = " & record.ID & "
"
            If Allcolumns = True Then
                Columns = New List(Of StudentCoursesColumns)()
                For Each c In System.Enum.GetValues(GetType(StudentCoursesColumns))
                    Columns.Add(c)
                Next
            End If
            Dim C_names As New List(Of String)()
            For Each c In Columns
                C_names.Add(c.ToString)
            Next
            Dim Fields_string As String = Nothing
            Dim gList = record.GetType.GetProperties.ToList.FindAll(Function(x) C_names.Contains(x.Name))
            Dim pLimit = gList.Count - 1
            Dim pCount = 0
            For Each P As PropertyInfo In gList
                pCount += 1
                Try
                    If P.Name = "AllowUpdate" Then
                        GoTo nextP
                    End If

                    If P.Name = "ID" Then
                        GoTo nextP
                    Else
                        Select Case pCount
                            Case 1
                                Fields_string = P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                            Case Else
                                Fields_string += "," & P.Name & " = '" & P.GetValue(record) & "'" & vbNewLine
                        End Select
                    End If
                Catch ex As Exception

                End Try
nextP:
            Next P
            cmd_str = cmd_str.Replace("{FIELDS}", Fields_string)
            '  MsgBox(cmd_str)
            Dim CMD_output = DBIO.DirectCommand(cmd_str)
            Return CMD_output
        End Function
#End Region
    End Class

End Namespace
